#pragma once
#include "pch.h"
#include "Test01.h"

class Answer6
{
public:
	Answer6();
	~Answer6();
	Answer6(const vector<string>& Answer);

	vector<string> AnswerTEST;

	vector<string> TEST();
};


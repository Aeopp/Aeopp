#pragma once
#include "pch.h"
#include "Test01.h"

class Answer4
{
public:
	Answer4();
	~Answer4();
	Answer4(const vector<string>& Answer);

	vector<string> AnswerTEST;

	vector<string> TEST();
};


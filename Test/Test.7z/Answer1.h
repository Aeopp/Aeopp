#pragma once
#include "pch.h"
#include "Test01.h"

class Answer1
{
public:
	Answer1();
	~Answer1();
	Answer1(const vector<string>& Answer);

	 vector<string> AnswerTEST;
	 vector<string> operator()();

};

